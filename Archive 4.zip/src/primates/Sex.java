package primates;

/**
 * An enum class to represent the different sexes in the sanctuary.
 */
public enum Sex {
  MALE, FEMALE
}
