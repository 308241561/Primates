package primates;

/**
 * An enum class to represent the different speices in the sanctuary.
 */
public enum Species {
  DRILL, GUEREZA, HOWLER, MANGABEY, SAKI, SPIDER, SQUIRREL, TAMARIN
}
