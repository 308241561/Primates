package primates;

/**
 * An enum class to represent the sizes of the sanctuary.
 */
public enum Size {
  SMALL, MEDIUM, LARGE
}
