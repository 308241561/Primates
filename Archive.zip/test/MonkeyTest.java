
import org.junit.Before;
import org.junit.Test;
import primates.*;

import static org.junit.Assert.*;

/**
 * This is a test class for Monkey.to test different functions of the monkey.
 */
public class MonkeyTest {

  private Monkey defaultMonkey;
  @Before
  public void setUp() {
    defaultMonkey = initialMon("Friday", Species.DRILL,Sex.MALE,Size.SMALL, 10,15, Food.EGGS);
  }

  /**
   *  This method is providing short-hand way of creating instances.
   * @param name name
   * @param species species
   * @param sex sex
   * @param monSize monSize
   * @param weight weight
   * @param age age
   * @param favFood favFood
   * @return  short-hand way of creating instances Monkey
   */

  protected Monkey initialMon(String name, Species species, Sex sex, Size monSize, int weight, int age, Food favFood){
    return new Monkey(name,species,sex,monSize,weight,age,favFood);
  }


  @Test(expected = IllegalArgumentException.class)
  public void testInvalidConstructMonkeyWithNegativeWeight(){
    Monkey mk = new Monkey("1", Species.DRILL, Sex.MALE,Size.SMALL,-1,1,Food.EGGS);
  }
  @Test(expected = IllegalArgumentException.class)
  public void testInvalidConstructMonkeyWithNullSize(){
    Monkey mk = new Monkey("1", Species.DRILL, Sex.MALE,null,-1,1,Food.EGGS);
  }
  @Test(expected = IllegalArgumentException.class)
  public void testInvalidConstructMonkeyWithNullFood(){
    Monkey mk = new Monkey("1", Species.DRILL, Sex.MALE,Size.SMALL,-1,1,null);
  }

  @Test
  public void testGetName() {
    String expected = "Friday";
    assertEquals(expected, defaultMonkey.getName());
  }

  @Test
  public void testGetSpecies() {
    Species expected = Species.DRILL;
    assertEquals(expected, defaultMonkey.getSpecies());
  }

  @Test
  public void testGetSex() {
    Sex expected = Sex.MALE;
    assertEquals(expected, defaultMonkey.getSex());
  }

  @Test
  public void testGetMonSize() {
    Size expected = Size.SMALL;
    assertEquals(expected, defaultMonkey.getMonSize());
  }

  @Test
  public void testGetWeight() {
    int expected = 10;
    assertEquals(expected, defaultMonkey.getWeight());
  }

  @Test
  public void testGetAge() {
    int expected = 15;
    assertEquals(expected, defaultMonkey.getAge());
  }

  @Test
  public void testGetFavFood() {
    Food expected = Food.EGGS;
    assertEquals(expected, defaultMonkey.getFavFood());
  }
}