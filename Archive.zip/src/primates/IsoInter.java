package primates;

public interface IsoInter {
  /**
   * To get the current monkey in the isolation.
   * @return monkey
   */
  Monkey getCurrMonkey();

  /**
   * To add a monkey to the isolation.
   * @param newMonkey a new monkey
   * @throws IllegalArgumentException if newMonkey is not correct type or the isolation is taken.
   */
  void addMonkey(Monkey newMonkey) throws IllegalArgumentException;

  /**
   * To remove the monkey from the isolation
   * @return a monkey
   * @throws IllegalStateException if the isolation is not currently occupied by a monkey.
   */
  Monkey removeMonkey() throws IllegalStateException;

}
