package primates;

/**
 * An enum class of food for the sanctuary.
 */
public enum Food {
  EGGS, FRUITS, INSECTS, LEAVES, NUTS, SEEDS, TREE_SAP
}
