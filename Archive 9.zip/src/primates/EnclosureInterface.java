package primates;

import java.util.ArrayList;

/**
 * This is the interface class for the enclosure.
 */
public interface EnclosureInterface {
  /**
   * Get the current enclosure's species.
   *
   * @return Species of the Monkeys
   */
  Species getCurrEnclosureSpecies();

  /**
   * Get the list of monkeys.
   *
   * @return list of monkeys
   */
  ArrayList<Monkey> getMonkeyList();

  /**
   * Get the current enclosure's capacity.
   *
   * @return current enclosure's capacity
   */
  int getCurrEnclosureCapacity();

  /**
   * Add a monkey to the enclosure.
   *
   * @param monkey monkey to be added
   * @throws IllegalArgumentException if monkey is not a required type of data
   */
  void addMonkey(Monkey monkey) throws IllegalArgumentException;

}
